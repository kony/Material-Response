function AS_Image_05506e9f147d4578b026d4000a5dae9c(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}