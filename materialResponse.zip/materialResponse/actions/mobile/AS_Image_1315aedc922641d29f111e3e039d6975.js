function AS_Image_1315aedc922641d29f111e3e039d6975(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}