function AS_Image_1cd81525bdee442f86e0c40a15fc1394(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}