function AS_Image_48e668ca4acb4124a43f9902f1862e62(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}