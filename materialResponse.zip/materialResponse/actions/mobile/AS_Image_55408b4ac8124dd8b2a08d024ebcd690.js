function AS_Image_55408b4ac8124dd8b2a08d024ebcd690(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}