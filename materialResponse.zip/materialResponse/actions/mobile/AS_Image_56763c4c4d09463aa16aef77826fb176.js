function AS_Image_56763c4c4d09463aa16aef77826fb176(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}