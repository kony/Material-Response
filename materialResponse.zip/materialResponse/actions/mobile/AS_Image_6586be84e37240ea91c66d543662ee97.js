function AS_Image_6586be84e37240ea91c66d543662ee97(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}