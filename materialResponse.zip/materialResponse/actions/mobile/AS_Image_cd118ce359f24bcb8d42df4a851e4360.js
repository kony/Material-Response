function AS_Image_cd118ce359f24bcb8d42df4a851e4360(eventobject, x, y) {
    return materialResponse.call(this, eventobject.id, x, y);
}